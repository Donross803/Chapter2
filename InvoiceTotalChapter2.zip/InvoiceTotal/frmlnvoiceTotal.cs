namespace InvoiceTotal
{
    public partial class frmlnvoiceTotal : Form
    {
        public frmlnvoiceTotal()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {


        }
    }
}
