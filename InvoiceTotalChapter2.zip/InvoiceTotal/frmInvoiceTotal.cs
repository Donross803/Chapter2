using System;
using System.Windows.Forms;

namespace InvoiceTotal
{
    public partial class frmInvoiceTotal : Form
    {
        public frmInvoiceTotal()
        {
            InitializeComponent();

            // wire up event handlers (designer file doesn't attach them)
            this.btnCalculate.Click += btnCalculate_Click;
            this.btnExit.Click += btnExit_Click;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Validate subtotal input
            if (!decimal.TryParse(txtSubtotal.Text, out decimal subtotal))
            {
                MessageBox.Show("Please enter a valid number for the subtotal.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSubtotal.Focus();
                return;
            }

            // Determine discount percent
            decimal discountPercent;

            if (subtotal >= 500m)
                discountPercent = 0.20m;
            else if (subtotal >= 250m)
                discountPercent = 0.15m;
            else if (subtotal >= 100m)
                discountPercent = 0.10m;
            else
                discountPercent = 0.00m;

            // Calculate discount and total
            decimal discountAmount = subtotal * discountPercent;
            decimal total = subtotal - discountAmount;

            // Display results (match designer control names)
            txtDiscountPct.Text = discountPercent.ToString("p1");
            txtDiscountAmt.Text = discountAmount.ToString("c");
            txtTotal.Text = total.ToString("c");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
